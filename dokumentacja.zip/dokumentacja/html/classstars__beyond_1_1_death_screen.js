var classstars__beyond_1_1_death_screen =
[
    [ "DeathScreen", "classstars__beyond_1_1_death_screen.html#a037253faac1dbfc66538d3086d6bb07e", null ],
    [ "OnDisappearing", "classstars__beyond_1_1_death_screen.html#ae5257811638d1d69cdc949e97ff5fb91", null ]
];
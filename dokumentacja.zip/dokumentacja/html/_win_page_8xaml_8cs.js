var _win_page_8xaml_8cs =
[
    [ "stars_beyond.WinPage", "classstars__beyond_1_1_win_page.html", "classstars__beyond_1_1_win_page" ]
];
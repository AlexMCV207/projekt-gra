var files_dup =
[
    [ "App.xaml.cs", "_app_8xaml_8cs.html", "_app_8xaml_8cs" ],
    [ "AppShell.xaml.cs", "_app_shell_8xaml_8cs.html", "_app_shell_8xaml_8cs" ],
    [ "ChainSfxService.cs", "_chain_sfx_service_8cs.html", "_chain_sfx_service_8cs" ],
    [ "CreditsPage.xaml.cs", "_credits_page_8xaml_8cs.html", "_credits_page_8xaml_8cs" ],
    [ "DeathScreen.xaml.cs", "_death_screen_8xaml_8cs.html", "_death_screen_8xaml_8cs" ],
    [ "GameplayPageMainUI.xaml.cs", "_gameplay_page_main_u_i_8xaml_8cs.html", "_gameplay_page_main_u_i_8xaml_8cs" ],
    [ "GlobalXmlns.cs", "_global_xmlns_8cs.html", null ],
    [ "IntroPage.xaml.cs", "_intro_page_8xaml_8cs.html", "_intro_page_8xaml_8cs" ],
    [ "MainMenu.xaml.cs", "_main_menu_8xaml_8cs.html", "_main_menu_8xaml_8cs" ],
    [ "MauiProgram.cs", "_maui_program_8cs.html", null ],
    [ "MusicService.cs", "_music_service_8cs.html", "_music_service_8cs" ],
    [ "OptionsPage.xaml.cs", "_options_page_8xaml_8cs.html", "_options_page_8xaml_8cs" ],
    [ "SfxService.cs", "_sfx_service_8cs.html", "_sfx_service_8cs" ],
    [ "WinPage.xaml.cs", "_win_page_8xaml_8cs.html", "_win_page_8xaml_8cs" ]
];
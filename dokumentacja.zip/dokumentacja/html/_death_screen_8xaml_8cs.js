var _death_screen_8xaml_8cs =
[
    [ "stars_beyond.DeathScreen", "classstars__beyond_1_1_death_screen.html", "classstars__beyond_1_1_death_screen" ]
];
var searchData=
[
  ['resetbattle_0',['ResetBattle',['../classstars__beyond_1_1_gameplay_page_main_u_i.html#a7cf75102fc02b3cf7b1f44c307b7909c',1,'stars_beyond::GameplayPageMainUI']]],
  ['restartfromdeath_1',['RestartFromDeath',['../classstars__beyond_1_1_gameplay_page_main_u_i.html#ab7ef5962463cccd86b2cf7b9d349224a',1,'stars_beyond::GameplayPageMainUI']]]
];

var searchData=
[
  ['app_0',['App',['../classstars__beyond_1_1_app.html',1,'stars_beyond.App'],['../classstars__beyond_1_1_app.html#a88e860f43c2f1ffbad800d67412ce7af',1,'stars_beyond.App.App()']]],
  ['app_2examl_2ecs_1',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['appshell_2',['AppShell',['../classstars__beyond_1_1_app_shell.html',1,'stars_beyond.AppShell'],['../classstars__beyond_1_1_app_shell.html#ae878b822d71b9a59ae1f2f5eb7813763',1,'stars_beyond.AppShell.AppShell()']]],
  ['appshell_2examl_2ecs_3',['AppShell.xaml.cs',['../_app_shell_8xaml_8cs.html',1,'']]]
];

var searchData=
[
  ['dirx_0',['DirX',['../classstars__beyond_1_1_chain_attack.html#a580d331022e4dda9f0ca1be2b3e93d3f',1,'stars_beyond::ChainAttack']]],
  ['diry_1',['DirY',['../classstars__beyond_1_1_chain_attack.html#af09b381c53309e832ec0a1e6aa5f55ea',1,'stars_beyond::ChainAttack']]]
];

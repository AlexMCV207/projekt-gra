var searchData=
[
  ['gameplaypagemainui_2examl_2ecs_0',['GameplayPageMainUI.xaml.cs',['../_gameplay_page_main_u_i_8xaml_8cs.html',1,'']]],
  ['globalxmlns_2ecs_1',['GlobalXmlns.cs',['../_global_xmlns_8cs.html',1,'']]]
];

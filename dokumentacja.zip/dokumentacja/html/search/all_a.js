var searchData=
[
  ['onappearing_0',['OnAppearing',['../classstars__beyond_1_1_gameplay_page_main_u_i.html#a04dcadbefdf5acbc3adb2caa04925d92',1,'stars_beyond.GameplayPageMainUI.OnAppearing()'],['../classstars__beyond_1_1_main_menu.html#a7bb277a78350d62097d8b0bdee9b2909',1,'stars_beyond.MainMenu.OnAppearing()']]],
  ['ondisappearing_1',['OnDisappearing',['../classstars__beyond_1_1_death_screen.html#ae5257811638d1d69cdc949e97ff5fb91',1,'stars_beyond.DeathScreen.OnDisappearing()'],['../classstars__beyond_1_1_intro_page.html#a1406d97fd545fba22330e0c17f8af184',1,'stars_beyond.IntroPage.OnDisappearing()']]],
  ['optionspage_2',['OptionsPage',['../classstars__beyond_1_1_options_page.html',1,'stars_beyond.OptionsPage'],['../classstars__beyond_1_1_options_page.html#a817d077075d6bd1374240d1e9cb1abcd',1,'stars_beyond.OptionsPage.OptionsPage()']]],
  ['optionspage_2examl_2ecs_3',['OptionsPage.xaml.cs',['../_options_page_8xaml_8cs.html',1,'']]]
];

var searchData=
[
  ['wintype_0',['WinType',['../classstars__beyond_1_1_win_page.html#a4d72763781dbdf62d818a1a4736e1241',1,'stars_beyond::WinPage']]]
];

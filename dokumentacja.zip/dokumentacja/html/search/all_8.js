var searchData=
[
  ['mainmenu_0',['MainMenu',['../classstars__beyond_1_1_main_menu.html',1,'stars_beyond.MainMenu'],['../classstars__beyond_1_1_main_menu.html#a49445c4dfa9c7ebda0ed27a57bdd9fff',1,'stars_beyond.MainMenu.MainMenu()'],['../classstars__beyond_1_1_main_menu.html#ad74bae1721534a9a09c17aa18ba94a7d',1,'stars_beyond.MainMenu.MainMenu(MusicService service, SfxService sfx)']]],
  ['mainmenu_2examl_2ecs_1',['MainMenu.xaml.cs',['../_main_menu_8xaml_8cs.html',1,'']]],
  ['mauiprogram_2ecs_2',['MauiProgram.cs',['../_maui_program_8cs.html',1,'']]],
  ['musicservice_3',['MusicService',['../class_music_service.html',1,'MusicService'],['../class_music_service.html#aa8b566b713a98452bc8d0818c16ee1f5',1,'MusicService.MusicService()']]],
  ['musicservice_2ecs_4',['MusicService.cs',['../_music_service_8cs.html',1,'']]]
];

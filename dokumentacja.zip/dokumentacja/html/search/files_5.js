var searchData=
[
  ['mainmenu_2examl_2ecs_0',['MainMenu.xaml.cs',['../_main_menu_8xaml_8cs.html',1,'']]],
  ['mauiprogram_2ecs_1',['MauiProgram.cs',['../_maui_program_8cs.html',1,'']]],
  ['musicservice_2ecs_2',['MusicService.cs',['../_music_service_8cs.html',1,'']]]
];

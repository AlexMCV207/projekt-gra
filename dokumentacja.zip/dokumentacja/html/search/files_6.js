var searchData=
[
  ['optionspage_2examl_2ecs_0',['OptionsPage.xaml.cs',['../_options_page_8xaml_8cs.html',1,'']]]
];

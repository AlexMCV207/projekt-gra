var searchData=
[
  ['gameplaypagemainui_0',['GameplayPageMainUI',['../classstars__beyond_1_1_gameplay_page_main_u_i.html',1,'stars_beyond.GameplayPageMainUI'],['../classstars__beyond_1_1_gameplay_page_main_u_i.html#ad08818dcd884a7c953d9e7b7b5d48395',1,'stars_beyond.GameplayPageMainUI.GameplayPageMainUI()']]],
  ['gameplaypagemainui_2examl_2ecs_1',['GameplayPageMainUI.xaml.cs',['../_gameplay_page_main_u_i_8xaml_8cs.html',1,'']]],
  ['globalxmlns_2ecs_2',['GlobalXmlns.cs',['../_global_xmlns_8cs.html',1,'']]]
];

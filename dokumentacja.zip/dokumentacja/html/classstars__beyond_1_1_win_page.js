var classstars__beyond_1_1_win_page =
[
    [ "WinType", "classstars__beyond_1_1_win_page.html#a4d72763781dbdf62d818a1a4736e1241", null ]
];
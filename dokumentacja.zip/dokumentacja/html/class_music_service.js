var class_music_service =
[
    [ "MusicService", "class_music_service.html#aa8b566b713a98452bc8d0818c16ee1f5", null ],
    [ "FadeOut", "class_music_service.html#a71ba079acfe169d05a113a45cd6cc9cf", null ],
    [ "Play", "class_music_service.html#a6e13bb30d46e2ff4c5869b6ad509c802", null ],
    [ "SetVolume", "class_music_service.html#aefcc8beaad769497dd0f7e805946b58e", null ],
    [ "Stop", "class_music_service.html#a6df7bb11594056463eade098e89c4e90", null ],
    [ "ShouldPlayMenuMusic", "class_music_service.html#a8a5393d93ed06ad45e2f7995f6aad291", null ]
];
var classstars__beyond_1_1_options_page =
[
    [ "OptionsPage", "classstars__beyond_1_1_options_page.html#a817d077075d6bd1374240d1e9cb1abcd", null ]
];
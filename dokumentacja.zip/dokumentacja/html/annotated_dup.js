var annotated_dup =
[
    [ "stars_beyond", "namespacestars__beyond.html", [
      [ "App", "classstars__beyond_1_1_app.html", "classstars__beyond_1_1_app" ],
      [ "AppShell", "classstars__beyond_1_1_app_shell.html", "classstars__beyond_1_1_app_shell" ],
      [ "ChainAttack", "classstars__beyond_1_1_chain_attack.html", "classstars__beyond_1_1_chain_attack" ],
      [ "CreditsPage", "classstars__beyond_1_1_credits_page.html", "classstars__beyond_1_1_credits_page" ],
      [ "DeathScreen", "classstars__beyond_1_1_death_screen.html", "classstars__beyond_1_1_death_screen" ],
      [ "GameplayPageMainUI", "classstars__beyond_1_1_gameplay_page_main_u_i.html", "classstars__beyond_1_1_gameplay_page_main_u_i" ],
      [ "IntroPage", "classstars__beyond_1_1_intro_page.html", "classstars__beyond_1_1_intro_page" ],
      [ "MainMenu", "classstars__beyond_1_1_main_menu.html", "classstars__beyond_1_1_main_menu" ],
      [ "OptionsPage", "classstars__beyond_1_1_options_page.html", "classstars__beyond_1_1_options_page" ],
      [ "WinPage", "classstars__beyond_1_1_win_page.html", "classstars__beyond_1_1_win_page" ]
    ] ],
    [ "ChainSfxService", "class_chain_sfx_service.html", "class_chain_sfx_service" ],
    [ "MusicService", "class_music_service.html", "class_music_service" ],
    [ "SfxService", "class_sfx_service.html", "class_sfx_service" ]
];
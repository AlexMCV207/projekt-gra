var classstars__beyond_1_1_app =
[
    [ "App", "classstars__beyond_1_1_app.html#a88e860f43c2f1ffbad800d67412ce7af", null ],
    [ "CreateWindow", "classstars__beyond_1_1_app.html#ad9f9549ae4e989b9c733f7287892e2c0", null ]
];
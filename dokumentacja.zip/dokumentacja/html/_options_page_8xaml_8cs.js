var _options_page_8xaml_8cs =
[
    [ "stars_beyond.OptionsPage", "classstars__beyond_1_1_options_page.html", "classstars__beyond_1_1_options_page" ]
];
var classstars__beyond_1_1_main_menu =
[
    [ "MainMenu", "classstars__beyond_1_1_main_menu.html#a49445c4dfa9c7ebda0ed27a57bdd9fff", null ],
    [ "MainMenu", "classstars__beyond_1_1_main_menu.html#ad74bae1721534a9a09c17aa18ba94a7d", null ],
    [ "OnAppearing", "classstars__beyond_1_1_main_menu.html#a7bb277a78350d62097d8b0bdee9b2909", null ]
];
var classstars__beyond_1_1_gameplay_page_main_u_i =
[
    [ "WinType", "classstars__beyond_1_1_gameplay_page_main_u_i.html#a6766a2149d5e32976c47f8150669ed45", [
      [ "None", "classstars__beyond_1_1_gameplay_page_main_u_i.html#a6766a2149d5e32976c47f8150669ed45a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Pacifist", "classstars__beyond_1_1_gameplay_page_main_u_i.html#a6766a2149d5e32976c47f8150669ed45a24bf4707fcf0977e9a79dd2c01c0a86f", null ],
      [ "Kill", "classstars__beyond_1_1_gameplay_page_main_u_i.html#a6766a2149d5e32976c47f8150669ed45a292ed5e525d66c64f13a3bf54a17c06a", null ]
    ] ],
    [ "GameplayPageMainUI", "classstars__beyond_1_1_gameplay_page_main_u_i.html#ad08818dcd884a7c953d9e7b7b5d48395", null ],
    [ "OnAppearing", "classstars__beyond_1_1_gameplay_page_main_u_i.html#a04dcadbefdf5acbc3adb2caa04925d92", null ],
    [ "ResetBattle", "classstars__beyond_1_1_gameplay_page_main_u_i.html#a7cf75102fc02b3cf7b1f44c307b7909c", null ],
    [ "RestartFromDeath", "classstars__beyond_1_1_gameplay_page_main_u_i.html#ab7ef5962463cccd86b2cf7b9d349224a", null ]
];
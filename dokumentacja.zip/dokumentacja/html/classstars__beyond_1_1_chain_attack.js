var classstars__beyond_1_1_chain_attack =
[
    [ "DirX", "classstars__beyond_1_1_chain_attack.html#a580d331022e4dda9f0ca1be2b3e93d3f", null ],
    [ "DirY", "classstars__beyond_1_1_chain_attack.html#af09b381c53309e832ec0a1e6aa5f55ea", null ],
    [ "Height", "classstars__beyond_1_1_chain_attack.html#a437401d45d7bd9d3dc057be22b7145cb", null ],
    [ "Sprite", "classstars__beyond_1_1_chain_attack.html#a3b7687a0630736ba352eb5be45c5cb1d", null ],
    [ "StopAfterInitialMove", "classstars__beyond_1_1_chain_attack.html#ad0ed8b691b818baa01b09c60e975eef8", null ],
    [ "Width", "classstars__beyond_1_1_chain_attack.html#a1804189950e71bf0b3b17b190db63eb9", null ]
];
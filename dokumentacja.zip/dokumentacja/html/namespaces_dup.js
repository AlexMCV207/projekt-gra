var namespaces_dup =
[
    [ "stars_beyond", "namespacestars__beyond.html", "namespacestars__beyond" ]
];